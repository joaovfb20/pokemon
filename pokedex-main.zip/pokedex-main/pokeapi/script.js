function busca(){
    let id = document.querySelector('#id').value
    let img = document.querySelector('img')
    let h2 = document.querySelector('h2')
    let p = document.querySelector('p')

    fetch(`https://pokeapi.co/api/v2/pokemon/${id}/`)
    .then(response => response.json())
    .then(data => {
        console.log(data)
        img.src = data.sprites.other['official-artwork'].front_default
        h2.innerHTML = data.id
        p.innerHTML = data.name
    })
    .catch(error => console.log(error))
}